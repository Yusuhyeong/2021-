package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        TextView with_petButton = (TextView) findViewById(R.id.registerButton);
        with_petButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                Intent registerIntent = new Intent(StartActivity.this, Withpet.class);
                StartActivity.this.startActivity(registerIntent);
            }
        });

        TextView find_loadButton = (TextView) findViewById(R.id.registerButton);
        find_loadButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                Intent registerIntent = new Intent(StartActivity.this, Findload.class);
                StartActivity.this.startActivity(registerIntent);
            }
        });

        TextView recommendButton = (TextView) findViewById(R.id.registerButton);
        recommendButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                Intent registerIntent = new Intent(StartActivity.this, Recommend.class);
                StartActivity.this.startActivity(registerIntent);
            }
        });

        TextView boardButton = (TextView) findViewById(R.id.registerButton);
        boardButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                Intent registerIntent = new Intent(StartActivity.this, Board.class);
                StartActivity.this.startActivity(registerIntent);
            }
        });
    }
}